let ebrimaMoney = 2

if(ebrimaMoney>239876){
    console.log("I'm rich")
} else {
    console.log("Yo Balram help me out please")
}